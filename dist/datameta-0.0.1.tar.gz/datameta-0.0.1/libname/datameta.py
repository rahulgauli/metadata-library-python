def sayhello():
    print("hello world")
    return "whaszup"
