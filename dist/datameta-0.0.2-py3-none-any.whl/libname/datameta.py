def sayhello():
    print("hello world")
    return "whaszup"

from libname.schema.dataschema import Programming

class Iterate:
    def __init__(self):
        self.start = 0
        self.end()
    
    def end():
        pass


